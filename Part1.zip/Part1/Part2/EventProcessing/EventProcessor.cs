﻿using Part2.Data;
using Part2.Dtos;
using Part2.Enteties;
using Part2.EventProcessing;
using System.Text.Json;

namespace CommandsService.EventProcessing
{
    public class EventProcessor : IEventProcessor
    {
        private readonly AppDbContext _context;
        private readonly ILogger<EventProcessor> _logger;

        public EventProcessor (AppDbContext context, ILogger<EventProcessor> logger)
        {
            _context = context;
            _logger = logger;
        }

        public void ProcessEvent(string message)
        {
            var eventType = DetermineEvent(message);

            switch (eventType)
            {
                case EventType.AddSalary:
                    {
                        AddSalary(message);
                    }
                    break;
                default:
                    break;
            }
        }

        private EventType DetermineEvent(string notifcationMessage)
        {
            _logger.LogInformation("--> Determining Event");

            var eventType = JsonSerializer.Deserialize<AddSalaryDTO>(notifcationMessage);

            switch (eventType.Event)
            {
                case "Add_Salary":
                    {
                        _logger.LogInformation("--> Platform Published Event Detected");

                        return EventType.AddSalary;
                    }
                default:
                    {
                        _logger.LogInformation("--> Could not determine the event type");

                        return EventType.Undetermined;
                    }
            }
        }

        private void AddSalary(string addSalaryMessage)
        {
            var message = JsonSerializer.Deserialize<AddSalaryDTO>(addSalaryMessage);
            var salary = new Salary
            {
                UserId = message.UserId,
                Amount = message.Amount
            };

            _context.Salaries.Add(salary);
            _context.SaveChanges();
        }
    }

    enum EventType
    {
        AddSalary,
        Undetermined
    }
}
