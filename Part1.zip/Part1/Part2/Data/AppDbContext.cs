﻿using Microsoft.EntityFrameworkCore;
using Part2.Enteties;
using Part2.Interfaces;

namespace Part2.Data
{
    public class AppDbContext : DbContext, IAppDbContext
    {
        public DbSet<Salary> Salaries { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }

        public async Task<int> SaveChangesAsync()
        {
            return await base.SaveChangesAsync();
        }
    }
}
