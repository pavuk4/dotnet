﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Part2.Enteties;
using Part2.Features.Commands;
using Part2.Features.Queries;

namespace Part2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SalaryController : ControllerBase
    {
        private IMediator _mediator;
        protected IMediator Mediator => _mediator ??= HttpContext.RequestServices.GetService<IMediator>();

        #region CRUD
        [HttpGet("get")]
        [ProducesResponseType(typeof(List<Salary>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetAllSalariesAsync()
        {
            return Ok(await Mediator.Send(new GetAllSalariesQuery()));
        }

        [HttpGet("get/{id}")]
        [ProducesResponseType(typeof(Salary), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetSalaryByIdAsync(int id)
        {
            return Ok(await Mediator.Send(new GetSalaryByIdQuery { Id = id }));
        }

        [HttpPost("create")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CreateSalaryAsync(CreateSalaryCommand command)
        {
            return Ok(await Mediator.Send(command));
        }

        [HttpPut("update/[action]")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateSalaryAsync(int id, UpdateSalaryCommand command)
        {
            return id == command.Id ? Ok(await Mediator.Send(command)) : BadRequest();
        }

        [HttpDelete("delete/{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> DeleteSalaryByIdAsync(int id)
        {
            return Ok(await Mediator.Send(new DeleteSalaryCommand { Id = id }));
        }
        #endregion
    }
}
