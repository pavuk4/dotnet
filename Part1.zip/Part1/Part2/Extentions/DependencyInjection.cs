﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Part2.Data;
using Part2.Interfaces;
using System.Reflection;

namespace Part2.Extentions
{
    public static class DependencyInjection
    {
        public static void AddAplication(this IServiceCollection services)
        {
            services.AddMediatR(Assembly.GetExecutingAssembly());
        }

        public static void AddPersistence(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<AppDbContext>(options =>
                options.UseSqlServer(
                    configuration["MSSQLConnection"],
                    b => b.MigrationsAssembly(typeof(AppDbContext).Assembly.FullName)));

            services.AddScoped<IAppDbContext>(provider => provider.GetService<AppDbContext>());
        }
    }
}
