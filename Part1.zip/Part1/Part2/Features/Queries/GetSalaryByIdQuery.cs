﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Part2.Enteties;
using Part2.Interfaces;

namespace Part2.Features.Queries
{
    public class GetSalaryByIdQuery : IRequest<Salary>
    {
        public int Id { get; set; }

        public class GetSalaryByIdQueryHandler : IRequestHandler<GetSalaryByIdQuery, Salary>
        {
            private readonly IAppDbContext _context;

            public GetSalaryByIdQueryHandler(IAppDbContext context)
            {
                _context = context;
            }

            public async Task<Salary> Handle(GetSalaryByIdQuery request, CancellationToken cancellationToken)
            {
                var earnings = await _context.Salaries.Where(e => e.Id == request.Id).FirstOrDefaultAsync();

                return earnings == null ? null : earnings;
            }
        }
    }
}
