﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Part2.Enteties;
using Part2.Interfaces;

namespace Part2.Features.Queries
{
    public class GetAllSalariesQuery : IRequest<IEnumerable<Salary>>
    {
        public class GetAllSalariesQueryHandler : IRequestHandler<GetAllSalariesQuery, IEnumerable<Salary>>
        {
            private readonly IAppDbContext _context;

            public GetAllSalariesQueryHandler(IAppDbContext context)
            {
                _context = context;
            }

            public async Task<IEnumerable<Salary>> Handle(GetAllSalariesQuery request, CancellationToken cancellationToken)
            {
                var earningsList = await _context.Salaries.ToListAsync();

                if (earningsList == null)
                {
                    return null;
                }

                return earningsList.AsReadOnly();
            }
        }
    }
}
