﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Part2.Interfaces;

namespace Part2.Features.Commands
{
    public class UpdateSalaryCommand : IRequest<int>
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public float Amount { get; set; }

        public class UpdateSalaryCommandHandler : IRequestHandler<UpdateSalaryCommand, int>
        {
            private readonly IAppDbContext _context;

            public UpdateSalaryCommandHandler(IAppDbContext context)
            {
                _context = context;
            }

            public async Task<int> Handle(UpdateSalaryCommand request, CancellationToken cancellationToken)
            {
                var salary = await _context.Salaries.Where(e => e.Id == request.Id).FirstOrDefaultAsync();

                if (salary == null)
                {
                    return default;
                }

                salary.UserId = request.UserId;
                salary.Amount = request.Amount;

                await _context.SaveChangesAsync();

                return salary.Id;
            }
        }
    }
}
