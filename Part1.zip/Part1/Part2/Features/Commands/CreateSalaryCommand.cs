﻿using MediatR;
using Part2.Enteties;
using Part2.Interfaces;

namespace Part2.Features.Commands
{
    public class CreateSalaryCommand : IRequest<int>
    {
        public int UserId { get; set; }
        public float Amount { get; set; }

        public class CreateSalaryCommandHandler : IRequestHandler<CreateSalaryCommand, int>
        {
            private readonly IAppDbContext _context;

            public CreateSalaryCommandHandler(IAppDbContext context)
            {
                _context = context;
            }

            public async Task<int> Handle(CreateSalaryCommand request, CancellationToken cancellationToken)
            {
                var salary = new Salary 
                { 
                    UserId = request.UserId, 
                    Amount= request.Amount 
                };

                _context.Salaries.Add(salary);
                await _context.SaveChangesAsync();

                return salary.Id;
            }
        }
    }
}
