﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Part2.Interfaces;

namespace Part2.Features.Commands
{
    public class DeleteSalaryCommand : IRequest<int>
    {
        public int Id { get; set; }

        public class DeleteSalaryByIdCommandHandler : IRequestHandler<DeleteSalaryCommand, int>
        {
            private readonly IAppDbContext _context;

            public DeleteSalaryByIdCommandHandler(IAppDbContext context)
            {
                _context = context;
            }

            public async Task<int> Handle(DeleteSalaryCommand request, CancellationToken cancellationToken)
            {
                var earnings = await _context.Salaries.Where(e => e.Id == request.Id).FirstOrDefaultAsync();

                if (earnings == null)
                {
                    return default;
                }

                _context.Salaries.Remove(earnings);
                await _context.SaveChangesAsync();

                return earnings.Id;
            }
        }
    }
}
