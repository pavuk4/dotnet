﻿using Microsoft.EntityFrameworkCore;
using Part2.Enteties;

namespace Part2.Interfaces
{
    public interface IAppDbContext
    {
        DbSet<Salary> Salaries { get; set; }

        Task<int> SaveChangesAsync();
    }
}
