﻿using Part2.Enteties;

namespace Part2.Grpc
{
    public interface ITypeDataClient
    {
        IEnumerable<PhoneNumberType> ReturnAllFabrics();
    }
}
