﻿using Grpc.Net.Client;
using Part2.Enteties;
using Part2.Protos;

namespace Part2.Grpc
{
    public class TypeDataClient : ITypeDataClient
    {
        private readonly IConfiguration _configuration;

        public TypeDataClient(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IEnumerable<PhoneNumberType> ReturnAllFabrics()
        {
            var channel = GrpcChannel.ForAddress(_configuration["GrpcPlatform"]);
            var client = new GrpcType.GrpcTypeClient(channel);
            var request = new GetAllRequest();

            try
            {
                var reply = client.GetAllTypes(request);
                var data = new List<PhoneNumberType>();

                foreach (var item in reply.Type)
                {
                    data.Add(new PhoneNumberType
                    {
                        Id = item.TypeId,
                        Name = item.Name
                    });
                }

                return data;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
