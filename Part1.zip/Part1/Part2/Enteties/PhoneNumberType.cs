﻿namespace Part2.Enteties
{
    public class PhoneNumberType
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
