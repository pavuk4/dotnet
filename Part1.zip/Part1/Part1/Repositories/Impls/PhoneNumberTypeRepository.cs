﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Part1.Data;
using Part1.Dtos;
using Part1.Enteties;
using Part1.Repositories.Interfaces;

namespace Part1.Repositories.Impls
{
    public class PhoneNumberTypeRepository : IPhoneNumberTypeRespository
    {
        private readonly AppDbContext _context;
        private readonly IMapper _mapper;

        public PhoneNumberTypeRepository(AppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task CreateAsync(PhoneNumberTypeCreateDTO entity)
        {
            var type = _mapper.Map<PhoneNumberType>(entity);

            await _context.PhoneNumberTypes.AddAsync(type);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(PhoneNumberType entity)
        {
            _context.PhoneNumberTypes.Remove(entity);

            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<PhoneNumberType>> GetAllAsync()
        {
            return await _context.PhoneNumberTypes.Include(t => t.PersonPhones).ToListAsync();
        }

        public async Task<PhoneNumberType> GetAsync(int id)
        {
            return await _context.PhoneNumberTypes.Include(t => t.PersonPhones).FirstOrDefaultAsync(t => t.Id == id);
        }

        public async Task UpdateAsync(int id, PhoneNumberType entity)
        {
            _context.Entry(entity).State = EntityState.Modified;

            await _context.SaveChangesAsync();
        }
    }
}
