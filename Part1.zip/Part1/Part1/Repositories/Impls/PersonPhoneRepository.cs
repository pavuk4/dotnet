﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Part1.Data;
using Part1.Dtos;
using Part1.Enteties;
using Part1.Repositories.Interfaces;

namespace Part1.Repositories.Impls
{
    public class PersonPhoneRepository : IPersonPhoneRepository
    {
        private readonly AppDbContext _context;
        private readonly IMapper _mapper;

        public PersonPhoneRepository(AppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task CreateAsync(PersonPhoneCreateDTO entity)
        {
            var phone = _mapper.Map<PersonPhone>(entity);

            await _context.PersonPhones.AddAsync(phone);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(PersonPhone entity)
        {
            _context.PersonPhones.Remove(entity);

            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<PersonPhone>> GetAllAsync()
        {
            return await _context.PersonPhones.Include(p => p.Person).Include(p => p.PhoneNumberType).ToListAsync();
        }

        public async Task<PersonPhone> GetAsync(int id)
        {
            return await _context.PersonPhones.Include(p => p.Person).Include(p => p.PhoneNumberType).FirstOrDefaultAsync(e => e.Id == id);
        }

        public async Task UpdateAsync(int id, PersonPhone entity)
        {
            _context.Entry(entity).State = EntityState.Modified;

            await _context.SaveChangesAsync();
        }
    }
}
