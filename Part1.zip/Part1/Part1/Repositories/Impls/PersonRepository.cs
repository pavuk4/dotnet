﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Part1.Data;
using Part1.Dtos;
using Part1.Enteties;
using Part1.Repositories.Interfaces;

namespace Part1.Repositories.Impls
{
    public class PersonRepository : IPersonRepository
    {
        private readonly AppDbContext _context;
        private readonly IMapper _mapper;

        public PersonRepository(AppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task CreateAsync(PersonCreateDTO entity)
        {
            var person = _mapper.Map<Person>(entity);

            await _context.Persons.AddAsync(person);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Person entity)
        {
            _context.Persons.Remove(entity);

            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Person>> GetAllAsync()
        {
            return await _context.Persons.Include(p => p.EmailAddress).Include(p => p.PhoneNumber).ToListAsync();
        }

        public async Task<Person> GetAsync(int id)
        {
            return await _context.Persons.Include(p => p.EmailAddress).Include(p => p.PhoneNumber).FirstOrDefaultAsync(e => e.Id == id);
        }

        public async Task UpdateAsync(int id, Person entity)
        {
            _context.Entry(entity).State = EntityState.Modified;

            await _context.SaveChangesAsync();
        }

        public int GetLastId()
        {
            return _context.Persons.Select(p => p.Id).Max();
        }
    }
}
