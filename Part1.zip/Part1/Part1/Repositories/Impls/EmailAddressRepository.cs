﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Part1.Data;
using Part1.Dtos;
using Part1.Enteties;
using Part1.Repositories.Interfaces;

namespace Part1.Repositories.Impls
{
    public class EmailAddressRepository : IEmailAddressRepository
    {
        private readonly AppDbContext _context;
        private readonly IMapper _mapper;

        public EmailAddressRepository(AppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task CreateAsync(EmailAddressCreateDTO entity)
        {
            var emailAddress = _mapper.Map<EmailAddress>(entity);

            await _context.EmailAddresses.AddAsync(emailAddress);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(EmailAddress entity)
        {
            _context.EmailAddresses.Remove(entity);

            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<EmailAddress>> GetAllAsync()
        {
            return await _context.EmailAddresses.Include(e => e.Person).ToListAsync();
        }

        public async Task<EmailAddress> GetAsync(int id)
        {
            return await _context.EmailAddresses.Include(e => e.Person).FirstOrDefaultAsync(e => e.Id == id);
        }

        public async Task UpdateAsync(int id, EmailAddress entity)
        {
            _context.Entry(entity).State= EntityState.Modified;

            await _context.SaveChangesAsync();
        }
    }
}
