﻿namespace Part1.Repositories.Interfaces
{
    public interface IGenericRepository<T, V> where T : class where V : class
    {
        Task<IEnumerable<T>> GetAllAsync();
        Task<T> GetAsync(int id);
        Task CreateAsync(V entity);
        Task UpdateAsync(int id, T entity);
        Task DeleteAsync(T entity);
    }
}
