﻿using Part1.Dtos;
using Part1.Enteties;

namespace Part1.Repositories.Interfaces
{
    public interface IEmailAddressRepository : IGenericRepository<EmailAddress, EmailAddressCreateDTO>
    {

    }
}
