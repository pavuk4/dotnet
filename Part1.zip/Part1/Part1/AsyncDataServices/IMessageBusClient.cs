﻿using Part1.Dtos;

namespace Part1.AsyncDataServices
{
    public interface IMessageBusClient
    {
        void AddSalary(AddSalaryDTO addSalaryDTO);
    }
}
