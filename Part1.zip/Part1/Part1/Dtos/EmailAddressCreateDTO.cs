﻿using System.ComponentModel.DataAnnotations;

namespace Part1.Dtos
{
    public class EmailAddressCreateDTO
    {
        [Required] public int PersonId { get; set; }
        [Required] public string Email { get; set; }
    }
}
