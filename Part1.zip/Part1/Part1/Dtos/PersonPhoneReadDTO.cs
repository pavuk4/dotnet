﻿using Part1.Enteties;

namespace Part1.Dtos
{
    public class PersonPhoneReadDTO
    {
        public int Id { get; set; }
        public int PersonId { get; set; }
        public int PhoneNumberTypeId { get; set; }
        public string PhoneNumber { get; set; }

        public Person Person { get; set; }
        public PhoneNumberType PhoneNumberType { get; set; }
    }
}
