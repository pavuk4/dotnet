﻿using System.ComponentModel.DataAnnotations;

namespace Part1.Dtos
{
    public class PersonPhoneCreateDTO
    {
        [Required] public int PersonId { get; set; }
        [Required] public int PhoneNumberTypeId { get; set; }
        [Required] public string PhoneNumber { get; set; }
    }
}
