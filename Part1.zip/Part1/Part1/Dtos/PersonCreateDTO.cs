﻿using System.ComponentModel.DataAnnotations;

namespace Part1.Dtos
{
    public class PersonCreateDTO
    {
        [Required] public string PersonType { get; set; }
        [Required] public string NameStyle { get; set; }
        [Required] public string Title { get; set; }
        [Required] public string FirstName { get; set; }
        [Required] public string MiddleName { get; set; }
        [Required] public string LastName { get; set; }
        [Required] public string Suffix { get; set; }
        [Required] public string AdditionalContactInfo { get; set; }
        [Required] public string Demographics { get; set; }
    }
}
