﻿namespace Part1.Dtos
{
    public class AddSalaryDTO
    {
        public int UserId { get; set; }
        public float Amount { get; set; }
        public string Event { get; set; }
    }
}
