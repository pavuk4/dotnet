﻿using System.ComponentModel.DataAnnotations;

namespace Part1.Dtos
{
    public class PhoneNumberTypeCreateDTO
    {
        [Required] public string Name { get; set; }
    }
}
