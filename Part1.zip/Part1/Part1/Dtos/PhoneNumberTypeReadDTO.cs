﻿using Part1.Enteties;

namespace Part1.Dtos
{
    public class PhoneNumberTypeReadDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public IEnumerable<PersonPhone> PersonPhones { get; set; }
    }
}
