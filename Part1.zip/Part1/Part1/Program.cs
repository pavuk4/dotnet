using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Part1.Data;
using Part1.Grpc;
using Part1.Repositories.Impls;
using Part1.Repositories.Interfaces;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddControllersWithViews()
    .AddNewtonsoftJson(
        options => options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
    );

builder.Services.AddDbContext<AppDbContext>(options => options.UseSqlServer(builder.Configuration["MSSQLConnection"]));

builder.Services.AddScoped<IEmailAddressRepository, EmailAddressRepository>();
builder.Services.AddScoped<IPersonRepository, PersonRepository>();
builder.Services.AddScoped<IPersonPhoneRepository, PersonPhoneRepository>();
builder.Services.AddScoped<IPhoneNumberTypeRespository, PhoneNumberTypeRepository>();

builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

builder.Services.AddGrpc();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.MapGrpcService<PhoneNumberTypeGrpcService>();

app.Run();
