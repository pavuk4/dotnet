﻿using AutoMapper;
using Grpc.Core;
using Part1.Protos;
using Part1.Repositories.Interfaces;

namespace Part1.Grpc
{
    public class PhoneNumberTypeGrpcService : GrpcType.GrpcTypeBase
    {
        private readonly IPhoneNumberTypeRespository _repository;

        public PhoneNumberTypeGrpcService(IPhoneNumberTypeRespository repository)
        {
            _repository = repository;
        }

        public override Task<TypeResponse> GetAllFabrics(GetAllRequest request, ServerCallContext context)
        {
            var response = new TypeResponse();
            var types = _repository.GetAllAsync().Result;

            foreach (var type in types)
            {
                response.Type.Add(new GrpcTypeModel
                {
                    TypeId = type.Id,
                    Name = type.Name,
                });
            }

            return Task.FromResult(response);
        }
    }
}
