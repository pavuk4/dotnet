﻿namespace Part1.Enteties
{
    public class PhoneNumberType
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public IEnumerable<PersonPhone> PersonPhones { get; set; }
    }
}
