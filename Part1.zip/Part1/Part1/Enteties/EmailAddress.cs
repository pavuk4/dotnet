﻿namespace Part1.Enteties
{
    public class EmailAddress
    {
        public int Id { get; set; }
        public int PersonId { get; set; }
        public string Email { get; set; }

        public Person Person { get; set; }
    }
}
