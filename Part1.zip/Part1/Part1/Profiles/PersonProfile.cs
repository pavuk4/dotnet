﻿using AutoMapper;
using Part1.Dtos;
using Part1.Enteties;

namespace Part1.Profiles
{
    public class PersonProfile : Profile
    {
        public PersonProfile() 
        {
            CreateMap<PersonCreateDTO, Person>();
            CreateMap<Person, PersonReadDTO>();
        }
    }
}
