﻿using AutoMapper;
using Part1.Dtos;
using Part1.Enteties;

namespace Part1.Profiles
{
    public class PersonPhoneProfile : Profile
    {
        public PersonPhoneProfile() 
        {
            CreateMap<PersonPhoneCreateDTO, PersonPhone>();
            CreateMap<PersonPhone, PersonPhoneReadDTO>();
        }
    }
}
