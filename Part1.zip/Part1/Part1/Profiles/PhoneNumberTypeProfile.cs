﻿using AutoMapper;
using Part1.Dtos;
using Part1.Enteties;

namespace Part1.Profiles
{
    public class PhoneNumberTypeProfile : Profile
    {
        public PhoneNumberTypeProfile() 
        {
            CreateMap<PhoneNumberTypeCreateDTO, PhoneNumberType>();
            CreateMap<PhoneNumberType, PhoneNumberTypeReadDTO>();
        }
    }
}
