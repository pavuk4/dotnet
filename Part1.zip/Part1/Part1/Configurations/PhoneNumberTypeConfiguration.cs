﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Part1.Enteties;

namespace Part1.Configurations
{
    public class PhoneNumberTypeConfiguration : IEntityTypeConfiguration<PhoneNumberType>
    {
        public void Configure(EntityTypeBuilder<PhoneNumberType> builder)
        {
            builder.Property(type => type.Id)
                   .UseIdentityColumn()
                   .IsRequired();

            builder.Property(type => type.Name)
                   .IsRequired()
                   .HasMaxLength(100);
        }
    }
}
