﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Part1.Enteties;

namespace Part1.Configurations
{
    public class EmailAddressConfiguration : IEntityTypeConfiguration<EmailAddress>
    {
        public void Configure(EntityTypeBuilder<EmailAddress> builder)
        {
            builder.Property(email => email.Id)
                   .UseIdentityColumn()
                   .IsRequired();

            builder.Property(email => email.Email)
                   .IsRequired()
                   .HasMaxLength(100);

            builder.HasOne(email => email.Person)
                   .WithOne(person => person.EmailAddress)
                   .HasForeignKey<EmailAddress>(email => email.PersonId)
                   .HasConstraintName("FK_EmailAddress_PersonId");
        }
    }
}
