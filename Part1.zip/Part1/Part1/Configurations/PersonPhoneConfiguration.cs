﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Part1.Enteties;
using System.Numerics;

namespace Part1.Configurations
{
    public class PersonPhoneConfiguration : IEntityTypeConfiguration<PersonPhone>
    {
        public void Configure(EntityTypeBuilder<PersonPhone> builder)
        {
            builder.Property(phone => phone.Id)
                   .UseIdentityColumn()
                   .IsRequired();

            builder.Property(phone => phone.PhoneNumber)
                   .IsRequired()
                   .HasMaxLength(100);

            builder.HasOne(phone => phone.Person)
                   .WithOne(person => person.PhoneNumber)
                   .HasForeignKey<PersonPhone>(phone => phone.PersonId)
                   .HasConstraintName("FK_PersonPhone_PersonId");

            builder.HasOne(phone => phone.PhoneNumberType)
                   .WithMany(type => type.PersonPhones)
                   .HasForeignKey(phone => phone.PhoneNumberTypeId)
                   .HasConstraintName("FK_PersonPhone_PhoneNumberTypeId");
        }
    }
}
