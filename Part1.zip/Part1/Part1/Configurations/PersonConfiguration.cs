﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Part1.Enteties;

namespace Part1.Configurations
{
    public class PersonConfiguration : IEntityTypeConfiguration<Person>
    {
        public void Configure(EntityTypeBuilder<Person> builder)
        {
            builder.Property(person => person.Id)
                   .UseIdentityColumn()
                   .IsRequired();

            builder.Property(person => person.PersonType)
                   .IsRequired()
                   .HasMaxLength(100);
            
            builder.Property(person => person.NameStyle)
                   .IsRequired()
                   .HasMaxLength(100);
            
            builder.Property(person => person.Title)
                   .IsRequired()
                   .HasMaxLength(100);
            
            builder.Property(person => person.FirstName)
                   .IsRequired()
                   .HasMaxLength(100);
            
            builder.Property(person => person.MiddleName)
                   .IsRequired()
                   .HasMaxLength(100);
            
            builder.Property(person => person.LastName)
                   .IsRequired()
                   .HasMaxLength(100);
            
            builder.Property(person => person.Suffix)
                   .IsRequired()
                   .HasMaxLength(100);
            
            builder.Property(person => person.AdditionalContactInfo)
                   .IsRequired()
                   .HasMaxLength(100);
            
            builder.Property(person => person.Demographics)
                   .IsRequired()
                   .HasMaxLength(100);
        }
    }
}
