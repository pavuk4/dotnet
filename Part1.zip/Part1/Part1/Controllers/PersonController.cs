﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Part1.AsyncDataServices;
using Part1.Dtos;
using Part1.Enteties;
using Part1.Repositories.Interfaces;

namespace Part1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonController : ControllerBase
    {
        private readonly IPersonRepository _repository;
        private readonly IMapper _mapper;
        private readonly IMessageBusClient _messageBusClient;

        public PersonController(IPersonRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        #region API
        [HttpGet("get")]
        [ProducesResponseType(typeof(List<PersonReadDTO>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<PersonReadDTO>>> GetAllPersonsAsync()
        {
            return Ok(_mapper.Map<IEnumerable<PersonReadDTO>>(await _repository.GetAllAsync()));
        }

        [HttpGet("get/{id}")]
        [ProducesResponseType(typeof(PersonReadDTO), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<PersonReadDTO>> GetPersonAsync(int id)
        {
            var person = await _repository.GetAsync(id);

            return person == null ? NotFound() : Ok(_mapper.Map<PersonReadDTO>(person));
        }

        [HttpPost("create")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CreatePersonAsync(PersonCreateDTO personCreateDTO)
        {
            await _repository.CreateAsync(personCreateDTO);

            try
            {
                var addSalaryDTO = new AddSalaryDTO
                {
                    UserId = _repository.GetLastId(),
                    Amount = 1000,
                    Event = "Add_Salary"
                };
                _messageBusClient.AddSalary(addSalaryDTO);
            }
            catch (Exception) { }

            return Created(nameof(GetPersonAsync), personCreateDTO);
        }

        [HttpPut("update/{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> UpdatePersonAsync(int id, Person person)
        {
            if (id != person.Id)
            {
                return BadRequest();
            }

            await _repository.UpdateAsync(id, person);

            return NoContent();
        }

        [HttpDelete("delete/{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> DeletePersonAsync(int id)
        {
            var personToDelete = await _repository.GetAsync(id);

            if (personToDelete == null)
            {
                return NotFound();
            }

            await _repository.DeleteAsync(personToDelete);

            return NoContent();
        }
        #endregion
    }
}
