﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Part1.Dtos;
using Part1.Enteties;
using Part1.Repositories.Interfaces;

namespace Part1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonPhoneController : ControllerBase
    {
        private readonly IPersonPhoneRepository _repository;
        private readonly IMapper _mapper;

        public PersonPhoneController(IPersonPhoneRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        #region API
        [HttpGet("get")]
        [ProducesResponseType(typeof(List<PersonPhoneReadDTO>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<PersonPhoneReadDTO>>> GetAllPersonPhonesAsync()
        {
            return Ok(_mapper.Map<IEnumerable<PersonPhoneReadDTO>>(await _repository.GetAllAsync()));
        }

        [HttpGet("get/{id}")]
        [ProducesResponseType(typeof(PersonPhoneReadDTO), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<PersonPhoneReadDTO>> GetPersonPhoneAsync(int id)
        {
            var phone = await _repository.GetAsync(id);

            return phone == null ? NotFound() : Ok(_mapper.Map<PersonPhoneReadDTO>(phone));
        }

        [HttpPost("create")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CreatePersonPhoneAsync(PersonPhoneCreateDTO personPhoneCreateDTO)
        {
            await _repository.CreateAsync(personPhoneCreateDTO);

            return Created(nameof(GetPersonPhoneAsync), personPhoneCreateDTO);
        }

        [HttpPut("update/{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> UpdatePersonPhoneAsync(int id, PersonPhone phone)
        {
            if (id != phone.Id)
            {
                return BadRequest();
            }

            await _repository.UpdateAsync(id, phone);

            return NoContent();
        }

        [HttpDelete("delete/{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> DeletePersonPhoneAsync(int id)
        {
            var personPhoneToDelete = await _repository.GetAsync(id);

            if (personPhoneToDelete == null)
            {
                return NotFound();
            }

            await _repository.DeleteAsync(personPhoneToDelete);

            return NoContent();
        }
        #endregion
    }
}
