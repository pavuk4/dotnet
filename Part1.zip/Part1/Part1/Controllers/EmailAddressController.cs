﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Part1.Dtos;
using Part1.Enteties;
using Part1.Repositories.Interfaces;
using System.Collections.Generic;

namespace Part1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailAddressController : ControllerBase
    {
        private readonly IEmailAddressRepository _repository;
        private readonly IMapper _mapper;

        public EmailAddressController(IEmailAddressRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        #region API
        [HttpGet("get")]
        [ProducesResponseType(typeof(List<EmailAddressReadDTO>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<EmailAddressReadDTO>>> GetAllEmailAddressesAsync()
        {
            return Ok(_mapper.Map<IEnumerable<EmailAddressReadDTO>>(await _repository.GetAllAsync()));
        }

        [HttpGet("get/{id}")]
        [ProducesResponseType(typeof(EmailAddressReadDTO), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<EmailAddressReadDTO>> GetEmailAddressAsync(int id)
        {
            var emailAddress = await _repository.GetAsync(id);

            return emailAddress == null ? NotFound() : Ok(_mapper.Map<EmailAddressReadDTO>(emailAddress));
        }

        [HttpPost("create")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CreateEmailAddressAsync(EmailAddressCreateDTO emailAddressCreateDTO)
        {
            await _repository.CreateAsync(emailAddressCreateDTO);

            return Created(nameof(GetEmailAddressAsync), emailAddressCreateDTO);
        }

        [HttpPut("update/{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> UpdateEmailAddressAsync(int id, EmailAddress emailAddress)
        {
            if (id != emailAddress.Id)
            {
                return BadRequest();
            }

            await _repository.UpdateAsync(id, emailAddress);

            return NoContent();
        }

        [HttpDelete("delete/{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> DeleteEmailAddressAsync(int id)
        {
            var emailAddressToDelete = await _repository.GetAsync(id);

            if (emailAddressToDelete == null)
            {
                return NotFound();
            }

            await _repository.DeleteAsync(emailAddressToDelete);

            return NoContent();
        }
        #endregion
    }
}
