﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Part1.Dtos;
using Part1.Enteties;
using Part1.Repositories.Interfaces;

namespace Part1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PhoneNumberTypeController : ControllerBase
    {
        private readonly IPhoneNumberTypeRespository _repository;
        private readonly IMapper _mapper;

        public PhoneNumberTypeController(IPhoneNumberTypeRespository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        #region API
        [HttpGet("get")]
        [ProducesResponseType(typeof(List<PhoneNumberTypeReadDTO>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<PhoneNumberTypeReadDTO>>> GetAllPhoneNumberTypesAsync()
        {
            return Ok(_mapper.Map<IEnumerable<PhoneNumberTypeReadDTO>>(await _repository.GetAllAsync()));
        }

        [HttpGet("get/{id}")]
        [ProducesResponseType(typeof(PhoneNumberTypeReadDTO), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<PhoneNumberTypeReadDTO>> GetPhoneNumberTypeAsync(int id)
        {
            var type = await _repository.GetAsync(id);

            return type == null ? NotFound() : Ok(_mapper.Map<PhoneNumberTypeReadDTO>(type));
        }

        [HttpPost("create")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CreatePersonPhoneAsync(PhoneNumberTypeCreateDTO phoneNumberTypeCreateDTO)
        {
            await _repository.CreateAsync(phoneNumberTypeCreateDTO);

            return Created(nameof(GetPhoneNumberTypeAsync), phoneNumberTypeCreateDTO);
        }

        [HttpPut("update/{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> UpdatePhoneNumberTypeAsync(int id, PhoneNumberType type)
        {
            if (id != type.Id)
            {
                return BadRequest();
            }

            await _repository.UpdateAsync(id, type);

            return NoContent();
        }

        [HttpDelete("delete/{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> DeletePhoneNumberTypeAsync(int id)
        {
            var phoneNumberTypeToDelete = await _repository.GetAsync(id);

            if (phoneNumberTypeToDelete == null)
            {
                return NotFound();
            }

            await _repository.DeleteAsync(phoneNumberTypeToDelete);

            return NoContent();
        }
        #endregion
    }
}
